package com.example.epica3.Exception;



// Clase de excepción personalizada
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String mensaje){
        super(mensaje);    
    }
}



